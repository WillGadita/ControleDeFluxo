package br.com.notas;

public class NotasWillian {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Notas de Química do Semestre Letivo. Aluno: Marcos.
		
		System.out.println("Notas de Química do Semestre Letivo. Aluno: Marcos.");
		
		 Double prova1 = 8.5;
		 Double prova2 = 7.3;
		 Double prova3 = 4.8;
		 Double prova4 = 7.9;
		 
		 
		 
		 Double parcial = (prova1 + prova2 + prova3 + prova4) / 4; 
		
		 System.out.println("Resultado parcial: " + parcial);
		 
		 
		 
		 System.out.println("Resultado do semestre: ");
		 
		 
		if (parcial >= 7) {
			 System.out.println("Parabéns!!! Está aprovado!!!");
		 }
		 else if (parcial >=5) {
			 System.out.println("Está de Recuperação!!! Precisa estudar mais!!!");
		 }
		 else {
			 System.out.println("Reprovado!!! Tente denovo!!!");
		 }
		 
	
		 
		
	}

	
	}


